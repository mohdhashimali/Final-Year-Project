<template>
  <section class="py-4 sm:py-4 dark:bg-coolGray-800 dark:text-coolGray-100">
    <div class="container p-6 mx-auto space-y-8">
      <div class="space-y-2 text-center">
        <h2 class="text-3xl font-bold">Homes near you</h2>
        <p class="font-serif text-sm dark:text-coolGray-400">
          Choose from our wide range of homes to rent.
        </p>
      </div>
      <div
        class="grid grid-cols-1 gap-x-4 gap-y-8 md:grid-cols-2 lg:grid-cols-5"
      >
        <div class="bg-white shadow p-3 rounded lg:w-64">
          <div>
            <div
              style="
                background-image: url('https://dbjpekgzfghzs.cloudfront.net/4c9ae572edbe41f8efc8dc669982c1844d0891cd-md.jpg');
              "
              class="bg-cover bg-center bg-gray-300 h-32 rounded"
            ></div>
          </div>
          <div class="mt-6">
            <p class="text-lg text-bold tracking-wide text-gray-600 mb-2">
              Home
            </p>
            <p class="text-sm text-gray-600 font-hairline">
              Gorgeous North Beach duplex by Pier 39
            </p>
          </div>
          <div
            class="mt-6 flex flex-wrap justify-between pt-3 space-x-2 text-xm dark:text-coolGray-400"
          >
            <span>$556</span>
            <router-link to="/homerent"
              class="rounded shadow-md flex items-center shadow bg-black px-4 py-2 text-white hover:bg-gray-700"
            >
              Rent Now
            </router-link>
          </div>
        </div>
        <div class="bg-white shadow p-3 rounded lg:w-64">
          <div>
            <div
              style="
                background-image: url('https://dbjpekgzfghzs.cloudfront.net/4c9ae572edbe41f8efc8dc669982c1844d0891cd-md.jpg');
              "
              class="bg-cover bg-center bg-gray-300 h-32 rounded"
            ></div>
          </div>
          <div class="mt-6">
            <p class="text-lg text-bold tracking-wide text-gray-600 mb-2">
              Home
            </p>
            <p class="text-sm text-gray-600 font-hairline">
              Gorgeous North Beach duplex by Pier 39
            </p>
          </div>
          <div
            class="mt-6 flex flex-wrap justify-between pt-3 space-x-2 text-xm dark:text-coolGray-400"
          >
            <span>$556</span>
            <router-link to="/homerent" 
              class="rounded shadow-md flex items-center shadow bg-black px-4 py-2 text-white hover:bg-gray-700"
            >
              Rent Now
            </router-link>
          </div>
        </div>
        <div class="bg-white shadow p-3 rounded lg:w-64">
          <div>
            <div
              style="
                background-image: url('https://dbjpekgzfghzs.cloudfront.net/4c9ae572edbe41f8efc8dc669982c1844d0891cd-md.jpg');
              "
              class="bg-cover bg-center bg-gray-300 h-32 rounded"
            ></div>
          </div>
          <div class="mt-6">
            <p class="text-lg text-bold tracking-wide text-gray-600 mb-2">
              Home
            </p>
            <p class="text-sm text-gray-600 font-hairline">
              Gorgeous North Beach duplex by Pier 39
            </p>
          </div>
          <div
            class="mt-6 flex flex-wrap justify-between pt-3 space-x-2 text-xm dark:text-coolGray-400"
          >
            <span>$556</span>
            <button
              class="rounded shadow-md flex items-center shadow bg-black px-4 py-2 text-white hover:bg-gray-700"
            >
              Rent Now
            </button>
          </div>
        </div>
        <div class="bg-white shadow p-3 rounded lg:w-64">
          <div>
            <div
              style="
                background-image: url('https://dbjpekgzfghzs.cloudfront.net/4c9ae572edbe41f8efc8dc669982c1844d0891cd-md.jpg');
              "
              class="bg-cover bg-center bg-gray-300 h-32 rounded"
            ></div>
          </div>
          <div class="mt-6">
            <p class="text-lg text-bold tracking-wide text-gray-600 mb-2">
              Home
            </p>
            <p class="text-sm text-gray-600 font-hairline">
              Gorgeous North Beach duplex by Pier 39
            </p>
          </div>
          <div
            class="mt-6 flex flex-wrap justify-between pt-3 space-x-2 text-xm dark:text-coolGray-400"
          >
            <span>$556</span>
            <button
              class="rounded shadow-md flex items-center shadow bg-black px-4 py-2 text-white hover:bg-gray-700"
            >
              Rent Now
            </button>
          </div>
        </div>
        <div class="bg-white shadow p-3 rounded lg:w-64">
          <div>
            <div
              style="
                background-image: url('https://dbjpekgzfghzs.cloudfront.net/4c9ae572edbe41f8efc8dc669982c1844d0891cd-md.jpg');
              "
              class="bg-cover bg-center bg-gray-300 h-32 rounded"
            ></div>
          </div>
          <div class="mt-6">
            <p class="text-lg text-bold tracking-wide text-gray-600 mb-2">
              Home
            </p>
            <p class="text-sm text-gray-600 font-hairline">
              Gorgeous North Beach duplex by Pier 39
            </p>
          </div>
          <div
            class="mt-6 flex flex-wrap justify-between pt-3 space-x-2 text-xm dark:text-coolGray-400"
          >
            <span>$556</span>
            <button
              class="rounded shadow-md flex items-center shadow bg-black px-4 py-2 text-white hover:bg-gray-700"
            >
              Rent Now
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>